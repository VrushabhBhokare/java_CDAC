package com.app.fruits;

import java.util.Scanner;

public class FruitBasket {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the basket size: ");
        int n = sc.nextInt();
        sc.nextLine();  // consume newline

        Fruit[] basket = new Fruit[n];
        int counter = 0;

        int option = -1;
        while (option != 0) {
            System.out.println("\nMenu:");
            System.out.println("0. Exit");
            System.out.println("1. Add Mango");
            System.out.println("2. Add Orange");
            System.out.println("3. Add Apple");
            System.out.println("4. Display names of all fruits in the basket");
            System.out.println("5. Display name, color, weight, taste of all fresh fruits");
            System.out.println("6. Mark a fruit as stale");
            System.out.println("7. Display tastes of all stale fruits");

            System.out.print("Choose an option: ");
            option = sc.nextInt();
            sc.nextLine();  // consume newline

            switch (option) {
                case 0:
                    System.out.println("Exiting...");
                    break;

                case 1: // Add Mango
                    if (counter >= n) {
                        System.out.println("Basket is full! Cannot add more fruits.");
                        break;
                    }
                    System.out.print("Enter name of Mango: ");
                    String mName = sc.nextLine();
                    System.out.print("Enter weight of Mango: ");
                    double mWeight = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Enter color of Mango: ");
                    String mColor = sc.nextLine();

                    basket[counter++] = new Mango(mName, mWeight, mColor);
                    System.out.println("Mango added.");
                    break;

                case 2: // Add Orange
                    if (counter >= n) {
                        System.out.println("Basket is full! Cannot add more fruits.");
                        break;
                    }
                    System.out.print("Enter name of Orange: ");
                    String oName = sc.nextLine();
                    System.out.print("Enter weight of Orange: ");
                    double oWeight = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Enter color of Orange: ");
                    String oColor = sc.nextLine();

                    basket[counter++] = new Orange(oName, oWeight, oColor);
                    System.out.println("Orange added.");
                    break;

                case 3: // Add Apple
                    if (counter >= n) {
                        System.out.println("Basket is full! Cannot add more fruits.");
                        break;
                    }
                    System.out.print("Enter name of Apple: ");
                    String aName = sc.nextLine();
                    System.out.print("Enter weight of Apple: ");
                    double aWeight = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Enter color of Apple: ");
                    String aColor = sc.nextLine();

                    basket[counter++] = new Apple(aName, aWeight, aColor);
                    System.out.println("Apple added.");
                    break;

                case 4: // Display names of all fruits
                    System.out.println("Names of fruits in basket:");
                    for (Fruit f : basket) {
                        if (f != null) {
                            System.out.println(f.getName());
                        }
                    }
                    break;

                case 5: // Display details & taste of fresh fruits
                    System.out.println("Fresh fruits details:");
                    for (Fruit f : basket) {
                        if (f != null && f.isFresh()) {
                            System.out.println(f.toString() + ", Taste: " + f.taste());
                        }
                    }
                    break;

                case 6: // Mark a fruit as stale
                    System.out.print("Enter index of fruit to mark stale (0 to " + (counter - 1) + "): ");
                    int idx = sc.nextInt();
                    sc.nextLine();

                    if (idx < 0 || idx >= counter || basket[idx] == null) {
                        System.out.println("Invalid index! Try again.");
                    } else {
                        basket[idx].setFresh(false);
                        System.out.println(basket[idx].getName() + " marked as stale.");
                    }
                    break;

                case 7: // Display tastes of stale fruits
                    System.out.println("Tastes of stale fruits:");
                    for (Fruit f : basket) {
                        if (f != null && !f.isFresh()) {
                            System.out.println(f.getName() + ": " + f.taste());
                        }
                    }
                    break;

                default:
                    System.out.println("Invalid option! Try again.");
            }
        }

        sc.close();
    }
}
