package com.sunbeam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Program05 {

	public static void main(String[] args) {
		final String URL = "jdbc:mysql://localhost:3306/dkte_db";
		final String USERNAME = "root";
		final String PASSWORD = "root";

		System.out.println("DELETE USER - ");

		try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
			String sql = "DELETE FROM user WHERE uid = ?";
			try (PreparedStatement deleteStatement = connection.prepareStatement(sql)) {
				try (Scanner sc = new Scanner(System.in)) {
					System.out.print("Enter the user id to delete - ");
					int uid = sc.nextInt();
					deleteStatement.setInt(1, uid);
					deleteStatement.executeUpdate();
					System.out.println("User Deleted ... :( ");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
