package com.sunbeam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Program02 {

	public static void main(String[] args) {
		final String URL = "jdbc:mysql://localhost:3306/dkte_db";
		final String USERNAME = "root";
		final String PASSWORD = "root";

		try {
			Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM user");
			ResultSet rs = statement.executeQuery();
			while (rs.next()) {
				System.out.println("uid - " + rs.getInt(1));
				System.out.println("Name - " + rs.getString(2));
				System.out.println("Email - " + rs.getString(3));
				System.out.println("City - " + rs.getString(5));
				System.out.println("-------------------------------");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
