
public class Program {

	public static void main(String[] args) {
		//int a = 10; // init
		//int a = 20;  // NOT OK 
		//initialization should be done only once 
		
		int b = 10; 
		b = 20; //Assignment 
		b = 30; //Assignment
		b = 40; //Assignment
		//Assignment can be done multiple number of times 
	}

}
