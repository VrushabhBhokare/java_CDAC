package com.sunbeam;
class Parent{
	public final void display( ) { // logically 100% complete 
		//TODO 
	}
}
class Child extends Parent{
	/*  // final method cannot be overrided 
	@Override
	public void display() {
		//TODO 
	}*/ 
}
public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
