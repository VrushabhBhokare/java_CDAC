package com.sunbeam;
final class Time{ // logically 100% complete 
	private int hrs; 
	private int mins; 
	private int secs; 
	public Time() {
		// TODO Auto-generated constructor stub
	}
	public void display( ) {
		System.out.printf("hrs : %d mins : %d secs : %d",hrs,mins,secs);
	}
}
//final classes cannot be inherited into any sub-class.
//"effectively" all methods in final class become final.

/* 
class GoodTime extends Time{
	
}*/ 
public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
