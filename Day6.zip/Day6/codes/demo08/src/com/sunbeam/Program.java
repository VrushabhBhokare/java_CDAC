package com.sunbeam;

public class Program {

	public static void main(String[] args) {
		Date dt1 = new Date(1, 1, 2020); 
		Date dt2 = new Date(1, 1, 2021); 
		
		boolean flag = (dt1 == dt2); 
		//System.out.println("Res = " + flag); 
		// We are comparing the references 
		// references cannot be same 
		
		flag = dt1.equals(dt2); 
		//System.out.println("Res = " + flag);
		// if we dont override equals method 
		// object class equals method gets called and it also compares references 
	
		flag = dt1.equals(dt2); 
		//System.out.println("Res = " + flag);
		
		flag = dt1.equals(null); 
		//System.out.println("Res = " + flag);
		
		flag = dt1.equals(dt1); 
		//System.out.println("Res = " + flag);
		
		flag = dt1.equals("28-06-2025"); 
		System.out.println("Res = " + flag);
	}

}
