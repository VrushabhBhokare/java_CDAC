package com.sunbeam;

public interface Shape {
	/*public static final*/double PI = 3.14; 
	/*public abstract*/double calcArea( ); 
	/*public abstract*/double calcPeri( ); 
	 
}
