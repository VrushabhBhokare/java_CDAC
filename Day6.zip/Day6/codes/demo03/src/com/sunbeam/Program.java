package com.sunbeam;
interface Printable{  // Interface 
	/*public static final*/int number = 10;
	/*public abstract*/void print( ); 
}
class Test implements Printable{ // service provider 
	@Override
	public void print() {
		System.out.println("Number : " + Printable.number);
	}
}
public class Program {

	public static void main(String[] args) { // service consumer 
		//Test t1 = new Test() ; 
		//t1.print();
		Printable p = new Test(); // polymorphic declaration (upcasting)
		p.print();
	}

}
