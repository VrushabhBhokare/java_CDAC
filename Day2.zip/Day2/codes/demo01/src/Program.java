
public class Program {

	public static void main(String[] args) {
		//variable declaration 
		double length = 10.00 , breadth = 2.00 , area;
		
		//Area calculation 
		area = length * breadth; 
		
		System.out.println("Area : " + area);
		
		//printf("area  = %d",area); 
		System.out.println("Length : " + length + " breadth " + breadth);
		System.out.printf("Area : %.2f",area);
		
	}

}
