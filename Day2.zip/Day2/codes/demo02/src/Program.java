import java.util.Scanner;


public class Program {
	
	/* 
	public static void main(String[] args) {
		//(user-name , roll , marks)
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Name : ");
		String name = sc.next(); 
		
		System.out.println("Roll : ");
		int roll = sc.nextInt();
		
		System.out.println("Marks : ");
		double marks = sc.nextDouble(); 
		
		System.out.println("Name : "+name);
		System.out.println("Roll : "+roll);
		System.out.println("Marks : "+marks);

	}*/
	/* 
	public static void main(String[] args) {
		//(user-name , roll , marks)
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Name : ");
		String name = sc.next(); 
		
		System.out.print("Roll : ");
		int roll = sc.nextInt();
		
		System.out.print("Marks : ");
		double marks = sc.nextDouble(); 
		
		System.out.println("Name : "+name);
		System.out.println("Roll : "+roll);
		System.out.println("Marks : "+marks);

	}*/
	public static void main(String[] args) {
		//(user-name , roll , marks)
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Name : ");
		String name = sc.nextLine(); 
		
		System.out.print("Roll : ");
		int roll = sc.nextInt();
		
		System.out.print("Marks : ");
		double marks = sc.nextDouble(); 
		
		System.out.println("Name : "+name);
		System.out.println("Roll : "+roll);
		System.out.println("Marks : "+marks);

	}

}
