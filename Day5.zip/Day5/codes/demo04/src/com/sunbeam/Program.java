package com.sunbeam;

class SuperClass {
    protected Number calculate(Integer i, Float f) {
        return 10; 
    }
}

class SubClass extends SuperClass {
	
	@Override
    /*protected or*/ public Number calculate(Integer i, Float f) {
        return 10; 
    }
}

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
