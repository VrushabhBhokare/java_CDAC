package com.sunbeam;

import java.util.Arrays;

public class Program {
	public static void main(String[] args) {
		int[] arr1 = {33, 2 , 1 , 14 ,13}; 
		
		for(int i = 0 ; i < arr1.length ; i++)
			System.out.println(arr1[i]);
		System.out.println("After sorting : ");
		
		System.out.println("" + Arrays.toString(arr1)); 
		
		Arrays.sort(arr1);
		
		for(int i = 0 ; i < arr1.length ; i++)
			System.out.println(arr1[i]);
	}
	
}
