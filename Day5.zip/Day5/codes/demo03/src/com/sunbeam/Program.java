package com.sunbeam;
class Person{
	String name; 
	int age; 
	public Person() {
		// TODO Auto-generated constructor stub
	}
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	public void showRecord( ) {
		System.out.println("Name : "+this.name);
		System.out.println("Age : "+this.age);
	}
	
}
class Employee extends Person{
	int empid; 
	double salary; 
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(String name, int age, int empid, double salary) {
		super(name, age); 
		this.empid = empid;
		this.salary = salary;
	}
	public void printRecord( ) {
		showRecord();
		System.out.println("Empid : "+this.empid);
		System.out.println("Salary : "+this.salary);
	}
	
}
public class Program {
	
	public static void main(String[] args) {
		Person p = new Person("Ketan", 31); 
		Employee emp = (Employee) p; // downcasting  
	}
	public static void main5(String[] args) {
		Person p = new Employee("Ketan", 31, 1, 1000.00); // Upcasting 
		System.out.println(p.name); // OK 
		System.out.println(p.age);// OK 
		//System.out.println(p.empid);
		//System.out.println(p.salary);
		Employee emp = (Employee) p; // downcasting 
		System.out.println(emp.name);
		System.out.println(emp.empid);
		System.out.println(emp.age);
		System.out.println(emp.salary);
		
	}
	public static void main4(String[] args) {
		Employee emp = new Employee("Ketan", 31, 1, 1000.00);
		Person p = emp; // upcasting 
		System.out.println(p.name);// OK 
		System.out.println(p.age); // OK
		emp = (Employee) p; // downcasting 
		System.out.println(emp.name);
		System.out.println(emp.age);
		System.out.println(emp.empid);
		System.out.println(emp.salary);
		
	}
	public static void main3(String[] args) {
		Employee emp = new Employee("Ketan", 31, 1, 1000.00); 
//		System.out.println(emp.name);// OK 
//		System.out.println(emp.age);// OK 
//		System.out.println(emp.empid);// OK 
//		System.out.println(emp.salary);// OK
		Person p = (Person)emp; // upcasting  
		System.out.println(p.name);// OK 
		System.out.println(p.age); // OK 
		//System.out.println(p.empid); // NOT OK 
		//System.out.println(p.salary);// NOT OK 
	}
	public static void main2(String[] args) {
		Employee emp = new Employee("Ketan", 31, 1, 1000.00);
		System.out.println(emp.name);
		System.out.println(emp.age);
		System.out.println(emp.empid);
		System.out.println(emp.salary);
	}
	public static void main1(String[] args) {
		Person p = new Person("Ketan", 31); 
		System.out.println(p.name);
		System.out.println(p.age);
	}

}






