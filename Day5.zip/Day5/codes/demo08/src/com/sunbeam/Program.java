package com.sunbeam;

public class Program {

	public static void main(String[] args) {
		Date dt1 = new Date(1, 1, 2020); 
		
		System.out.println("toString() : "+dt1.toString());

	}

}
